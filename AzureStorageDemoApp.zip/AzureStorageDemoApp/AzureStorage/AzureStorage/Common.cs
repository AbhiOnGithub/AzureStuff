﻿using Microsoft.WindowsAzure.Storage;
using System;

namespace AzureStorage
{
    public static class Common

    {

        /// <summary>
        /// Validates the connection string information in app.config and throws an exception if it looks like 
        /// the user hasn't updated this to valid values. 
        /// </summary>
        /// <returns>CloudStorageAccount object</returns>
        public static CloudStorageAccount CreateStorageAccountFromConnectionString()

        {

            CloudStorageAccount storageAccount;
            const string Message = "Invalid storage account information provided. Please confirm the AccountName and AccountKey are valid in the app.config file - then restart the sample.";


            try
            {
                 storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=masteringazure;AccountKey=GRSHa80SIX94f9JR6tU3EXS2PwOqhWA0sIo7P/9OHAEqt4ygRdpcY69OeFYbeJipWXRACBRK2cBlXyvy9QQn6w==;EndpointSuffix=core.windows.net");
                
            }
            catch (FormatException)
            {

                Console.WriteLine(Message);
                Console.ReadLine();
                throw;

            }

            catch (ArgumentException)
            {
                Console.WriteLine(Message);
                Console.ReadLine();
                throw;

            }
            
            return storageAccount;
        }
    }
}
