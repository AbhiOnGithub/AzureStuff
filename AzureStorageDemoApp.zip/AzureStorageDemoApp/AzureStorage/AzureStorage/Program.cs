﻿using System;

namespace AzureStorage
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            BlobStorageDemo.CallBlobGettingStartedSamples();
        }
    }
}
